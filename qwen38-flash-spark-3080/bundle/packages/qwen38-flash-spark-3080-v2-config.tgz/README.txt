Qwen3.8 Flash-Next V2 runtime overlay. Mount model assets separately.
